import 'package:flutter/material.dart';
import 'package:notlarim/localization/localization.dart';
import 'package:path/path.dart';

import '../model/kategoriler.dart';
import '../model/notlar.dart';
import '../model/oncelikler.dart';
import 'database_helper.dart';

class NotHelper {
  final DatabaseHelper _databaseHelper = DatabaseHelper.instance;

  ///*** NOT ile ilgili Veritabanı İşlemleri ***
  ///Notlarda Tek Satır  Okuma İşlemi
  Future<Notlar> getNotId(int id) async {
    final db = await _databaseHelper.database;

    final maps = await db.query(
      tableNotlar,
      columns: NotlarAlanlar.values,
      where: '${NotlarAlanlar.id} = ?',
      whereArgs: [id],
    );

    if (maps.isNotEmpty) {
      return Notlar.fromJson(maps.first);
    } else {
      throw Exception('ID $id not found');
    }
  }

  ///Notlarda Kayıtları Listeleme İşlemi
  Future<List<Notlar>> getAllNot() async {
    final db = await _databaseHelper.database;

    const orderBy = '${NotlarAlanlar.kayitZamani} ASC';

    final result = await db.query(tableNotlar, orderBy: orderBy);

    return result.map((json) => Notlar.fromJson(json)).toList();
  }

  Future<List<Notlar>> searchNot(String searchText) async {
    final db = await _databaseHelper.database;
    final result = await db.query(tableNotlar,
        where: 'baslik LIKE ?', whereArgs: ['%$searchText%']);
    return result.map((json) => Notlar.fromJson(json)).toList();
  }

  /// Notlarda Kayıtları Listeleme İşlemi
  Future<List<Map<String, dynamic>>> getAllNotWithDetails() async {
    final db = await _databaseHelper.database;

    const orderBy = '${NotlarAlanlar.kayitZamani} ASC';

    final result = await db.query(tableNotlar, orderBy: orderBy);

    final List<Map<String, dynamic>> notlarWithDetails = [];

    for (final not in result) {
      final oncelikId = not[NotlarAlanlar.oncelikId] as int;
      final kategoriId = not[NotlarAlanlar.kategoriId] as int;

      final oncelikResult = await db.query(
        tableOncelik,
        where: '${OncelikAlanlar.id} = ?',
        whereArgs: [oncelikId],
      );

      final kategoriResult = await db.query(
        tableKategoriler,
        where: '${KategoriAlanlar.id} = ?',
        whereArgs: [kategoriId],
      );

      final oncelik = Oncelikler.fromJson(oncelikResult.first);
      final kategori = Kategoriler.fromJson(kategoriResult.first);

      final Map<String, dynamic> notWithDetails = {
        'not': Notlar.fromJson(not),
        'oncelik': oncelik,
        'kategori': kategori,
      };

      notlarWithDetails.add(notWithDetails);
    }

    return notlarWithDetails;
  }

  ///Notlarda Kayıtları Listeleme İşlemi Durum Id ye göre
  Future<List<Notlar>> getNotByDurum(int durumId) async {
    final db = await _databaseHelper.database;

    final result = await db.query(
      tableNotlar,
      where: '${NotlarAlanlar.id} = ?',
      whereArgs: [durumId],
    );

    return result.map((json) => Notlar.fromJson(json)).toList();
  }

  ///Notlarda Kayıtları Listeleme İşlemi Kategori Id ye göre
  Future<List<Notlar>> getNotByKategori(int kategoriId) async {
    final db = await _databaseHelper.database;

    final result = await db.query(
      tableNotlar,
      where: '${NotlarAlanlar.kategoriId} = ?',
      whereArgs: [kategoriId],
    );

    return result.map((json) => Notlar.fromJson(json)).toList();
  }

  ///Notlarda Kayıtları Listeleme İşlemi Öncelik Id ye göre
  Future<List<Notlar>> getNotByOncelik(int oncelikId) async {
    final db = await _databaseHelper.database;

    final result = await db.query(
      tableNotlar,
      where: '${NotlarAlanlar.oncelikId} = ?',
      whereArgs: [oncelikId],
    );

    return result.map((json) => Notlar.fromJson(json)).toList();
  }

  ///Notlara Kayıt Ekleme İşlemi
  Future<Notlar> createNot(Notlar not) async {
    final db = await _databaseHelper.database;

    final id = await db.insert(tableNotlar, not.toJson());
    return not.copy(id: id);
  }

  ///Notlarda Kayıt Değiştirme İşlemi
  Future<int> updateNot(Notlar not) async {
    final db = await _databaseHelper.database;

    return db.update(
      tableNotlar,
      not.toJson(),
      where: '${NotlarAlanlar.id} = ?',
      whereArgs: [not.id],
    );
  }

  ///Notlardan Kayıt Silme İşlemi
  Future<int> deleteNot(int id) async {
    final db = await _databaseHelper.database;

    return await db.delete(
      tableNotlar,
      where: '${NotlarAlanlar.id} = ?',
      whereArgs: [id],
    );
  }
}
