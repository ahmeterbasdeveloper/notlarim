import 'package:flutter/material.dart';
import 'package:notlarim/localization/localization.dart';
import 'package:path/path.dart';

import '../model/gorevler.dart';
import 'database_helper.dart';

class GorevHelper {
  final DatabaseHelper _databaseHelper = DatabaseHelper.instance;

  ///*** GÖREVLER ile ilgili Veritabanı İşlemleri ***
  ///Görev Tek Satır  Okuma İşlemi
  Future<Gorevler> getGorevId(int id) async {
    final db = await _databaseHelper.database;

    final maps = await db.query(
      tableGorevler,
      columns: GorevAlanlar.values,
      where: '${GorevAlanlar.id} = ?',
      whereArgs: [id],
    );

    if (maps.isNotEmpty) {
      return Gorevler.fromJson(maps.first);
    } else {
      throw Exception('ID $id not found');
    }
  }

  ///Durum Kayıtları Listeleme İşlemi
  Future<List<Gorevler>> getAllGorev() async {
    final db = await _databaseHelper.database;

    const orderBy = '${GorevAlanlar.kayitZamani} ASC';

    final result = await db.query(tableGorevler, orderBy: orderBy);

    return result.map((json) => Gorevler.fromJson(json)).toList();
  }

  ///Durum Kayıt Ekleme İşlemi
  Future<Gorevler> createGorev(Gorevler gorev) async {
    final db = await _databaseHelper.database;

    final id = await db.insert(tableGorevler, gorev.toJson());
    return gorev.copy(id: id);
  }

  ///Durum Kayıt Değiştirme İşlemi
  Future<int> updateGorev(Gorevler gorev) async {
    final db = await _databaseHelper.database;

    return db.update(
      tableGorevler,
      gorev.toJson(),
      where: '${GorevAlanlar.id} = ?',
      whereArgs: [gorev.id],
    );
  }

  ///Durum Kayıt Silme İşlemi
  Future<int> deleteGorev(int id) async {
    final db = await _databaseHelper.database;

    return await db.delete(
      tableGorevler,
      where: '${GorevAlanlar.id} = ?',
      whereArgs: [id],
    );
  }
}
