import 'dart:io';

import 'package:flutter/material.dart';
import 'package:notlarim/localization/localization.dart';
import 'package:notlarim/model/durumlar.dart';
import 'package:notlarim/model/gorevler.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

import '../model/hatirlatici.dart';
import '../model/kategoriler.dart';
import '../model/kullanicilar.dart';
import '../model/notlar.dart';
import '../model/kontrol_liste.dart';
import '../model/oncelikler.dart';

class DatabaseHelper {
  static int pathDbDirectoryTip =
      2; //eğer 1 (bir) ise getApplicationDocumentsDirectory, 2 (iki) ise getDatabasesPath olacak

  static const _databaseName = "notlar.db";
  static const _databaseVersion = 1;

  static final DatabaseHelper instance = DatabaseHelper._init();

  static Database? _database;

  DatabaseHelper._init();

  Future<Database> get database async {
    if (_database != null) return _database!;

    _database = await _initDB(_databaseName);
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    if (pathDbDirectoryTip == 1) {
      //getApplicationDocumentsDirectory
      Directory documentsDirectory = await getApplicationDocumentsDirectory();
      String path = join(documentsDirectory.path, _databaseName);
      return await openDatabase(path,
          version: _databaseVersion, onCreate: _onCreate);
    } else {
      //getDatabasesPath
      final dbPath = await getDatabasesPath();
      final path = join(dbPath, _databaseName);

      return await openDatabase(path, version: 1, onCreate: _onCreate);
    }
  }
/* #region Main */

/* #endregion */

  static Future<void> _onCreate(Database db, int version) async {
    ///Tiplerin SQLite karşılıkları dönüşümler
    const idType = 'INTEGER PRIMARY KEY AUTOINCREMENT';
    const textType = 'TEXT NOT NULL';
    const integerType = 'INTEGER NOT NULL';

    // Notlar tablosunu kontrol et ve varsa oluşturma
    await _createNotlarTable(db, idType, textType, integerType);

    // Notlar Liste  tablosunu kontrol et ve varsa oluşturma
    await _createKontrolListeTable(db, idType, textType, integerType);

    // Durumlar tablosunu kontrol et ve varsa oluşturma
    await _createDurumlarTable(db, idType, textType, integerType);

    // Kategoriler tablosunu kontrol et ve varsa oluşturma
    await _createKategorilerTable(db, idType, textType, integerType);

    // Öncelik tablosunu kontrol et ve varsa oluşturma
    await _createOncelikTable(db, idType, textType, integerType);

    // Görevler tablosunu kontrol et ve varsa oluşturma
    await _createGorevlerTable(db, idType, textType, integerType);

    // Hatırlatıcı tablosunu kontrol et ve varsa oluşturma
    await _createHatirlaticiTable(db, idType, textType, integerType);

    // Kullanıcı tablosunu kontrol et ve varsa oluşturma
    await _createKullaniciTable(db, idType, textType, integerType);
  }

  static Future<void> _createNotlarTable(
      Database db, String idType, String textType, String integerType) async {
    final notlarTableExists = await _tableExists(db, tableNotlar);
    if (!notlarTableExists) {
      await db.execute('''
      CREATE TABLE $tableNotlar ( 
        ${NotlarAlanlar.id} $idType, 
        ${NotlarAlanlar.kategoriId} $integerType,
        ${NotlarAlanlar.oncelikId} $integerType,
        ${NotlarAlanlar.baslik} $textType,
        ${NotlarAlanlar.aciklama} $textType,
        ${NotlarAlanlar.kayitZamani} $textType,
        ${NotlarAlanlar.durumId} $integerType
        )
      ''');
      await _insertDefaultNotlar(db);
    }
  }

  static Future<void> _insertDefaultNotlar(Database db) async {
    final defaultNotlar = [
      {
        'kategoriId': 1,
        'oncelikId': 1,
        'baslik': 'İlk Not BaşlıkDefault',
        'aciklama': 'İlk Not Açıklama Default',
        'kayitZamani': DateTime.now().toIso8601String(),
        'durumId': 1
      },
    ];

    for (final notlar in defaultNotlar) {
      await db.insert(tableNotlar, notlar);
    }
  }

  static Future<void> _createKontrolListeTable(
      Database db, String idType, String textType, String integerType) async {
    final kontrolListeTableExists = await _tableExists(db, tableKontrolListe);
    if (!kontrolListeTableExists) {
      await db.execute('''
      CREATE TABLE $tableKontrolListe ( 
        ${KontrolListeAlanlar.id} $idType, 
        ${KontrolListeAlanlar.baslik} $textType,
        ${KontrolListeAlanlar.aciklama} $textType,
        ${KontrolListeAlanlar.kategoriId} $integerType,
        ${KontrolListeAlanlar.oncelikId} $integerType,
        ${KontrolListeAlanlar.kayitZamani} $textType,
        ${KontrolListeAlanlar.durumId} $integerType
        )
      ''');
      // Tablo oluşturulduktan sonra kayıtları ekleyin
      await _insertDefaultKontrolListe(db);
    }
  }

  static Future<void> _insertDefaultKontrolListe(Database db) async {
    // Ekleme yapılacak varsayılan durumlar listesi
    final defaultKontrolListe = [
      {
        'baslik': 'İlk Kontrol Liste Başlık Default',
        'aciklama': 'İlk Kontrol Liste Açıklama Default',
        'kategoriId': 1,
        'oncelikId': 1,
        'kayitZamani': DateTime.now().toIso8601String(),
        'durumId': 1
      },
    ];

    // Her bir varsayılan durumu tabloya ekle
    for (final kontrolListe in defaultKontrolListe) {
      await db.insert(
        tableKontrolListe,
        kontrolListe,
      );
    }
  }

  static Future<void> _createDurumlarTable(
      Database db, String idType, String textType, String integerType) async {
    final durumlarTableExists = await _tableExists(db, tableDurumlar);
    if (!durumlarTableExists) {
      await db.execute('''
      CREATE TABLE $tableDurumlar ( 
        ${DurumAlanlar.id} $idType, 
        ${DurumAlanlar.baslik} $textType,
        ${DurumAlanlar.aciklama} $textType,
        ${DurumAlanlar.renkKodu} $textType,
        ${DurumAlanlar.kayitZamani} $textType,
        ${DurumAlanlar.sabitMi} $integerType
        )
      ''');
      // Tablo oluşturulduktan sonra kayıtları ekleyin
      await _insertDefaultDurumlar(db);
    }
  }

  static Future<void> _insertDefaultDurumlar(Database db) async {
    // Ekleme yapılacak varsayılan durumlar listesi
    final defaultDurumlar = [
      {
        'baslik': 'Yeni',
        'aciklama': 'Yapılacak İş',
        'renkKodu': '#E2945B',
        'kayitZamani': DateTime.now().toIso8601String(),
        'sabitMi': 1
      },
      {
        'baslik': 'Süreç Devam Ediyor',
        'aciklama': 'İş başladı ve devam ediyor.',
        'renkKodu': '#AB582C',
        'kayitZamani': DateTime.now().toIso8601String(),
        'sabitMi': 1
      },
      {
        'baslik': 'Süresi Belirsiz',
        'aciklama': 'Belli bir süresi olmayan,',
        'renkKodu': '#35D217',
        'kayitZamani': DateTime.now().toIso8601String(),
        'sabitMi': 1
      },
      {
        'baslik': 'Tamamlandı',
        'aciklama': 'Tamamlanan/Yapılan İş',
        'renkKodu': '#39C73F',
        'kayitZamani': DateTime.now().toIso8601String(),
        'sabitMi': 1
      },
      {
        'baslik': 'İptal Edildi',
        'aciklama': 'İşten vazgeçildi.',
        'renkKodu': '#FF067B',
        'kayitZamani': DateTime.now().toIso8601String(),
        'sabitMi': 1
      }
    ];

    // Her bir varsayılan durumu tabloya ekle
    for (final durum in defaultDurumlar) {
      await db.insert(
        tableDurumlar,
        durum,
      );
    }
  }

  static Future<void> _createKategorilerTable(
      Database db, String idType, String textType, String integerType) async {
    final kategorilerTableExists = await _tableExists(db, tableKategoriler);
    if (!kategorilerTableExists) {
      await db.execute('''
      CREATE TABLE $tableKategoriler ( 
        ${KategoriAlanlar.id} $idType, 
        ${KategoriAlanlar.baslik} $textType,
        ${KategoriAlanlar.aciklama} $textType,
        ${KategoriAlanlar.renkKodu} $textType,
        ${KategoriAlanlar.kayitZamani} $textType,
        ${KategoriAlanlar.sabitMi} $integerType 
        )
      ''');
      // Tablo oluşturulduktan sonra kayıtları ekleyin
      await _insertDefaultKategoriler(db);
    }
  }

  static Future<void> _insertDefaultKategoriler(Database db) async {
    // Ekleme yapılacak varsayılan durumlar listesi
    final defaultKategoriler = [
      {
        'baslik': 'Özel',
        'aciklama': 'Özel İşler',
        'renkKodu': '#55DC67',
        'kayitZamani': DateTime.now().toIso8601String(),
        'sabitMi': 1
      },
      {
        'baslik': 'Alış Veriş',
        'aciklama': 'Alış Veriş İşleri',
        'renkKodu': '#70DCFF',
        'kayitZamani': DateTime.now().toIso8601String(),
        'sabitMi': 0
      },
    ];

    // Her bir varsayılan durumu tabloya ekle
    for (final kategori in defaultKategoriler) {
      await db.insert(
        tableKategoriler,
        kategori,
      );
    }
  }

  static Future<void> _createOncelikTable(
      Database db, String idType, String textType, String integerType) async {
    final oncelikTableExists = await _tableExists(db, tableOncelik);
    if (!oncelikTableExists) {
      await db.execute('''
      CREATE TABLE $tableOncelik ( 
        ${OncelikAlanlar.id} $idType, 
        ${OncelikAlanlar.baslik} $textType,
        ${OncelikAlanlar.aciklama} $textType,
        ${OncelikAlanlar.renkKodu} $textType,
        ${OncelikAlanlar.kayitZamani} $textType,
         ${OncelikAlanlar.sabitMi} $integerType
        )
      ''');
      // Tablo oluşturulduktan sonra kayıtları ekleyin
      await _insertDefaultOncelikler(db);
    }
  }

  static Future<void> _insertDefaultOncelikler(Database db) async {
    // Ekleme yapılacak varsayılan durumlar listesi
    final defaultOncelikler = [
      {
        'baslik': 'Önemsiz',
        'aciklama': 'Öncelik Önemsiz',
        'renkKodu': '#DFD293',
        'kayitZamani': DateTime.now().toIso8601String(),
        'sabitMi': 1
      },
      {
        'baslik': 'Düşük',
        'aciklama': 'Öncelik Düşük',
        'renkKodu': '#E1D37D',
        'kayitZamani': DateTime.now().toIso8601String(),
        'sabitMi': 1
      },
      {
        'baslik': 'Orta',
        'aciklama': 'Öncelik Orta',
        'renkKodu': '#AACB70',
        'kayitZamani': DateTime.now().toIso8601String(),
        'sabitMi': 1
      },
      {
        'baslik': 'Yüksek',
        'aciklama': 'Öncelik Yüksek',
        'renkKodu': '#73C25F',
        'kayitZamani': DateTime.now().toIso8601String(),
        'sabitMi': 1
      },
      {
        'baslik': 'Acil',
        'aciklama': 'Öncelik Acil',
        'renkKodu': '#E4354F',
        'kayitZamani': DateTime.now().toIso8601String(),
        'sabitMi': 1
      }
    ];

    // Her bir varsayılan durumu tabloya ekle
    for (final oncelikler in defaultOncelikler) {
      await db.insert(
        tableOncelik,
        oncelikler,
      );
    }
  }

  static Future<void> _createGorevlerTable(
      Database db, String idType, String textType, String integerType) async {
    final gorevlerTableExists = await _tableExists(db, tableGorevler);
    if (!gorevlerTableExists) {
      await db.execute('''
      CREATE TABLE $tableGorevler ( 
        ${GorevAlanlar.id} $idType, 
         ${GorevAlanlar.grupId} $integerType,
        ${GorevAlanlar.baslik} $textType,
        ${GorevAlanlar.aciklama} $textType,
        ${GorevAlanlar.kategoriId} $integerType,
        ${GorevAlanlar.oncelikId} $integerType,
        ${GorevAlanlar.baslamaTarihiZamani} $textType,
        ${GorevAlanlar.bitisTarihiZamani} $textType,
        ${GorevAlanlar.kayitZamani} $textType,
        ${GorevAlanlar.durumId} $integerType
        )
      ''');
      // Tablo oluşturulduktan sonra kayıtları ekleyin
      await _insertDefaultGorevler(db);
    }
  }

  static Future<void> _insertDefaultGorevler(Database db) async {
    // Ekleme yapılacak varsayılan durumlar listesi
    final defaultGorevler = [
      {
        'grupId': 0,
        'baslik': 'İlk Görev/İş Başlık Default',
        'aciklama': 'İlk HGörev/İş Açıklama Default',
        'kategoriId': 1,
        'oncelikId': 1,
        'baslamaTarihiZamani': DateTime.now().toIso8601String(),
        'bitisTarihiZamani': DateTime.now().toIso8601String(),
        'kayitZamani': DateTime.now().toIso8601String(),
        'durumId': 1
      },
    ];
    // Her bir varsayılan durumu tabloya ekle
    for (final gorevler in defaultGorevler) {
      await db.insert(
        tableGorevler,
        gorevler,
      );
    }
  }

  static Future<void> _createHatirlaticiTable(
      Database db, String idType, String textType, String integerType) async {
    final hatirlaticiTableExists = await _tableExists(db, tableHatirlaticilar);
    if (!hatirlaticiTableExists) {
      await db.execute('''
      CREATE TABLE $tableHatirlaticilar ( 
        ${HatirlaticilarAlanlar.id} $idType, 
        ${HatirlaticilarAlanlar.baslik} $textType,
        ${HatirlaticilarAlanlar.aciklama} $textType,
        ${HatirlaticilarAlanlar.kategoriId} $integerType,
        ${HatirlaticilarAlanlar.oncelikId} $integerType,
        ${HatirlaticilarAlanlar.hatirlatmaTarihiZamani} $textType,
        ${HatirlaticilarAlanlar.kayitZamani} $textType,
        ${HatirlaticilarAlanlar.durumId} $integerType
        )
      ''');
      // Tablo oluşturulduktan sonra kayıtları ekleyin
      await _insertDefaultHatirlatici(db);
    }
  }

  static Future<void> _insertDefaultHatirlatici(Database db) async {
    // Ekleme yapılacak varsayılan durumlar listesi
    final defaultHatirlatici = [
      {
        'baslik': 'İlk Hatırlatıcı Başlık Default',
        'aciklama': 'İlk Hatırlatıcı Açıklama Default',
        'kategoriId': 1,
        'oncelikId': 1,
        'hatirlatmaTarihiZamani': DateTime.now().toIso8601String(),
        'kayitZamani': DateTime.now().toIso8601String(),
        'durumId': 1
      },
    ];
    // Her bir varsayılan durumu tabloya ekle
    for (final hatirlatici in defaultHatirlatici) {
      await db.insert(
        tableHatirlaticilar,
        hatirlatici,
      );
    }
  }

  static Future<void> _createKullaniciTable(
      Database db, String idType, String textType, String integerType) async {
    final kullaniciTableExists = await _tableExists(db, tableKullanicilar);
    if (!kullaniciTableExists) {
      await db.execute('''
      CREATE TABLE $tableKullanicilar ( 
        ${KullaniciAlanlar.id} $idType, 
        ${KullaniciAlanlar.ad} $textType,
        ${KullaniciAlanlar.soyad} $textType,
        ${KullaniciAlanlar.email} $textType,
        ${KullaniciAlanlar.password} $textType,
        ${KullaniciAlanlar.fotoUrl} $textType
        )
      ''');
      // Tablo oluşturulduktan sonra kayıtları ekleyin
      // await _insertDefaultHatirlatici(db);
    }
  }

  static Future<bool> _tableExists(Database db, String tableName) async {
    final query = '''
    SELECT name 
    FROM sqlite_master 
    WHERE type='table' 
    AND name='$tableName'
  ''';
    final result = await db.rawQuery(query);
    return result.isNotEmpty;
  }

  Future close() async {
    final db = await instance.database;

    db.close();
  }

  ///*** HATIRLATICI ile ilgili Veritabanı İşlemleri ***
  ///Hatırlatıcı Tek Satır  Okuma İşlemi
  Future<Hatirlaticilar> getHatirlaticiId(int id) async {
    final db = await instance.database;

    final maps = await db.query(
      tableHatirlaticilar,
      columns: HatirlaticilarAlanlar.values,
      where: '${HatirlaticilarAlanlar.id} = ?',
      whereArgs: [id],
    );

    if (maps.isNotEmpty) {
      return Hatirlaticilar.fromJson(maps.first);
    } else {
      throw Exception('ID $id not found');
    }
  }
}
