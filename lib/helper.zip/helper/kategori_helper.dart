import 'package:flutter/material.dart';
import 'package:notlarim/localization/localization.dart';
import 'package:path/path.dart';

import '../model/kategoriler.dart';
import 'database_helper.dart';

class KategoriHelper {
  final DatabaseHelper _databaseHelper = DatabaseHelper.instance;

  ///*** KATAGORİ ile ilgili Veritabanı İşlemleri ***
  ///İlk Kategoriyi bulan kod
  Future<Kategoriler> getIlkKategori() async {
    final db = await _databaseHelper.database;

    final result = await db.query(
      tableKategoriler,
      orderBy: '${KategoriAlanlar.id} ASC',
      limit: 1,
    );

    if (result.isNotEmpty) {
      return Kategoriler.fromJson(result.first);
    } else {
      throw Exception(AppLocalizations.of(context as BuildContext)
          .translate('general_notFound'));
    }
  }

  ///Kategori Tek Satır  Okuma İşlemi
  Future<Kategoriler> getKategoriId(int id) async {
    final db = await _databaseHelper.database;

    final maps = await db.query(
      tableKategoriler,
      columns: KategoriAlanlar.values,
      where: '${KategoriAlanlar.id} = ?',
      whereArgs: [id],
    );

    if (maps.isNotEmpty) {
      return Kategoriler.fromJson(maps.first);
    } else {
      throw Exception('ID $id not found');
    }
  }

  ///Kategorilerde Kayıtları Listeleme İşlemi
  Future<List<Kategoriler>> getAllKategori() async {
    final db = await _databaseHelper.database;

    const orderBy = '${KategoriAlanlar.kayitZamani} ASC';

    final result = await db.query(tableKategoriler, orderBy: orderBy);

    return result.map((json) => Kategoriler.fromJson(json)).toList();
  }

  ///Kategorilere Kayıt Ekleme İşlemi
  Future<Kategoriler> createKategori(Kategoriler kategori) async {
    final db = await _databaseHelper.database;

    final id = await db.insert(tableKategoriler, kategori.toJson());
    return kategori.copy(id: id);
  }

  ///Kategorilerden Kayıt Değiştirme İşlemi
  Future<int> updateKategori(Kategoriler kategori) async {
    final db = await _databaseHelper.database;

    return db.update(
      tableKategoriler,
      kategori.toJson(),
      where: '${KategoriAlanlar.id} = ?',
      whereArgs: [kategori.id],
    );
  }

  ///Kategorilerden Kayıt Silme İşlemi
  Future<int> deleteKategori(int id) async {
    final db = await _databaseHelper.database;

    return await db.delete(
      tableKategoriler,
      where: '${KategoriAlanlar.id} = ?',
      whereArgs: [id],
    );
  }
}
