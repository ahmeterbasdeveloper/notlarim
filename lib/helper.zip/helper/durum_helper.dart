import 'package:flutter/material.dart';
import 'package:notlarim/localization/localization.dart';
import 'package:path/path.dart';

import '../model/durumlar.dart';
import 'database_helper.dart';

class DurumHelper {
  final DatabaseHelper _databaseHelper = DatabaseHelper.instance;

  ///*** DURUMLAR ile ilgili Veritabanı İşlemleri ***
  ///Durum Tek Satır  Okuma İşlemi
  Future<Durumlar> getDurumId(int id) async {
    final db = await _databaseHelper.database;

    final maps = await db.query(
      tableDurumlar,
      columns: DurumAlanlar.values,
      where: '${DurumAlanlar.id} = ?',
      whereArgs: [id],
    );

    if (maps.isNotEmpty) {
      return Durumlar.fromJson(maps.first);
    } else {
      throw Exception('ID $id not found');
    }
  }

  ///Durum Kayıtları Listeleme İşlemi
  Future<List<Durumlar>> getAllDurum() async {
    final db = await _databaseHelper.database;

    const orderBy = '${DurumAlanlar.kayitZamani} ASC';

    final result = await db.query(tableDurumlar, orderBy: orderBy);

    return result.map((json) => Durumlar.fromJson(json)).toList();
  }

  ///Durum Kayıt Ekleme İşlemi
  Future<Durumlar> createDurum(Durumlar durum) async {
    final db = await _databaseHelper.database;

    final id = await db.insert(tableDurumlar, durum.toJson());
    return durum.copy(id: id);
  }

  ///Durum Kayıt Değiştirme İşlemi
  Future<int> updateDurum(Durumlar durum) async {
    final db = await _databaseHelper.database;

    return db.update(
      tableDurumlar,
      durum.toJson(),
      where: '${DurumAlanlar.id} = ?',
      whereArgs: [durum.id],
    );
  }

  ///Durum Kayıt Silme İşlemi
  Future<int> deleteDurum(int id) async {
    final db = await _databaseHelper.database;

    return await db.delete(
      tableDurumlar,
      where: '${DurumAlanlar.id} = ?',
      whereArgs: [id],
    );
  }
}
