import 'package:flutter/material.dart';
import 'package:path/path.dart';

import '../localization/localization.dart';
import '../model/notlar.dart';
import '../model/kontrol_liste.dart';
import 'database_helper.dart';

class KontrolListeListeHelper {
  final DatabaseHelper _databaseHelper = DatabaseHelper.instance;

  ///*** NOTLİSTE ile ilgili Veritabanı İşlemleri ***
  ///Notlarda Tek Satır  Okuma İşlemi
  Future<KontrolListe> getKontrolListeId(int id) async {
    final db = await _databaseHelper.database;

    final maps = await db.query(
      tableKontrolListe,
      columns: KontrolListeAlanlar.values,
      where: '${KontrolListeAlanlar.id} = ?',
      whereArgs: [id],
    );

    if (maps.isNotEmpty) {
      return KontrolListe.fromJson(maps.first);
    } else {
      throw Exception('ID $id not found');
    }
  }

  ///NotlarListe de Kayıtları Listeleme İşlemi
  Future<List<KontrolListe>> getAllKontrolListe() async {
    final db = await _databaseHelper.database;

    const orderBy = '${KontrolListeAlanlar.kayitZamani} ASC';

    final result = await db.query(tableKontrolListe, orderBy: orderBy);

    return result.map((json) => KontrolListe.fromJson(json)).toList();
  }

  ///NotlarListe Kayıtları Listeleme İşlemi Durum Id ye göre
  Future<List<KontrolListe>> getKontrolListeByDurum(int durumId) async {
    final db = await _databaseHelper.database;

    final result = await db.query(
      tableNotlar,
      where: '${KontrolListeAlanlar.id} = ?',
      whereArgs: [durumId],
    );

    return result.map((json) => KontrolListe.fromJson(json)).toList();
  }

  ///NotlarListeye Kayıt Ekleme İşlemi
  Future<KontrolListe> createKontrolListe(KontrolListe notListe) async {
    final db = await _databaseHelper.database;

    final id = await db.insert(tableKontrolListe, notListe.toJson());
    return notListe.copy(id: id);
  }

  ///NotlarListede Kayıt Değiştirme İşlemi
  Future<int> updateKontrolListe(KontrolListe notListe) async {
    final db = await _databaseHelper.database;

    return db.update(
      tableKontrolListe,
      notListe.toJson(),
      where: '${KontrolListeAlanlar.id} = ?',
      whereArgs: [notListe.id],
    );
  }

  ///NotlarListeden Kayıt Silme İşlemi
  Future<int> deleteKontrolListe(int id) async {
    final db = await _databaseHelper.database;

    return await db.delete(
      tableKontrolListe,
      where: '${KontrolListeAlanlar.id} = ?',
      whereArgs: [id],
    );
  }
}
