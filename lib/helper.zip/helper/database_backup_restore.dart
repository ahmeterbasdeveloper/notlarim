import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

import '../core/app_config.dart';

class DatabaseBackupRestore {
  static final DatabaseBackupRestore instance = DatabaseBackupRestore._init();
  late Database _database;

  DatabaseBackupRestore._init();

  Future<Database> get database async {
    return _database;
  }

  Future<String> _getDatabasePath(String dbName) async {
    if (AppConfig.pathDbDirectoryTip == 1) {
      Directory documentsDirectory = await getApplicationDocumentsDirectory();
      return join(documentsDirectory.path, dbName);
    } else {
      final dbPath = await getDatabasesPath();
      return join(dbPath, dbName);
    }
  }

  Future<void> backupDatabase(String fileName) async {
    String originalPath = await _getDatabasePath(AppConfig.databaseName);
    Directory? externalDir = await getExternalStorageDirectory();
    if (externalDir != null) {
      String backupPath = join(externalDir.path, '$fileName.db');
      await _copyFile(originalPath, backupPath);
      if (kDebugMode) {
        print('Yedek Başarılı şekilde alındı');
      }
    } else {
      if (kDebugMode) {
        print('Yedek alınamadı');
      }
    }
  }

  Future<void> restoreDatabase(String fileName) async {
    String originalPath = await _getDatabasePath(AppConfig.databaseName);
    Directory? externalDir = await getExternalStorageDirectory();
    if (externalDir != null) {
      String backupPath = join(externalDir.path, fileName);
      await _copyFile(backupPath, originalPath);
      if (kDebugMode) {
        print('Yedek Başarılı Şekilde Geri Yüklendi');
      }
    } else {
      if (kDebugMode) {
        print('Yedekten dönme işlemi başarısız oldu !!!!!!!');
      }
    }
  }

  Future<void> _copyFile(String sourcePath, String destinationPath) async {
    try {
      File sourceFile = File(sourcePath);
      if (await sourceFile.exists()) {
        await sourceFile.copy(destinationPath);
      } else {
        if (kDebugMode) {
          print('osya ulunamadı');
        }
      }
    } catch (e) {
      if (kDebugMode) {
        print('Veritabanı Yedek Alma Hatası: $e');
      }
    }
  }
}
