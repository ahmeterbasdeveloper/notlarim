import 'package:flutter/material.dart';
import 'package:notlarim/helper/oncelik_helper.dart';
import 'package:notlarim/model/oncelikler.dart';

class DataProvider extends ChangeNotifier {
  List<Oncelikler> appOncelikler = [];

  List<Oncelikler> get dataList => appOncelikler;

  void fetchData() async {
    appOncelikler = await OncelikHelper().getAllOncelik();
    notifyListeners();
  }
}
