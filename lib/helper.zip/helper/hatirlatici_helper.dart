import '../model/hatirlatici.dart';
import 'database_helper.dart';

class HatirlaticiHelper {
  final DatabaseHelper _databaseHelper = DatabaseHelper.instance;

  ///*** HATIRLATICI ile ilgili Veritabanı İşlemleri ***
  ///Hatırlatıcı Kayıtları Listeleme İşlemi
  Future<List<Hatirlaticilar>> getAllHatirlatici() async {
    final db = await _databaseHelper.database;

    const orderBy = '${HatirlaticilarAlanlar.kayitZamani} ASC';

    final result = await db.query(tableHatirlaticilar, orderBy: orderBy);

    return result.map((json) => Hatirlaticilar.fromJson(json)).toList();
  }

  ///Hatırlatıcı Kayıtları Listeleme İşlemi Durum Id ye göre
  Future<List<Hatirlaticilar>> getHatirlaticiByDurum(int durumId) async {
    final db = await _databaseHelper.database;

    final result = await db.query(
      tableHatirlaticilar,
      where: '${HatirlaticilarAlanlar.id} = ?',
      whereArgs: [durumId],
    );

    return result.map((json) => Hatirlaticilar.fromJson(json)).toList();
  }

  ///Hatirlaticilar'a Kayıt Ekleme İşlemi
  Future<Hatirlaticilar> createHatirlatici(Hatirlaticilar hatirlatici) async {
    final db = await _databaseHelper.database;

    final id = await db.insert(tableHatirlaticilar, hatirlatici.toJson());
    return hatirlatici.copy(id: id);
  }

  ///Hatirlaticida Kayıt Değiştirme İşlemi
  Future<int> updateHatirlatici(Hatirlaticilar hatirlatici) async {
    final db = await _databaseHelper.database;

    return db.update(
      tableHatirlaticilar,
      hatirlatici.toJson(),
      where: '${HatirlaticilarAlanlar.id} = ?',
      whereArgs: [hatirlatici.id],
    );
  }

  ///Hatirlaticilardan Kayıt Silme İşlemi
  Future<int> deleteHatirlatici(int id) async {
    final db = await _databaseHelper.database;

    return await db.delete(
      tableHatirlaticilar,
      where: '${HatirlaticilarAlanlar.id} = ?',
      whereArgs: [id],
    );
  }
}
