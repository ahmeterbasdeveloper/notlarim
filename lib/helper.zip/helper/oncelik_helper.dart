import 'package:flutter/material.dart';
import 'package:notlarim/localization/localization.dart';
import 'package:path/path.dart';

import '../model/oncelikler.dart';
import 'database_helper.dart';

class OncelikHelper {
  final DatabaseHelper _databaseHelper = DatabaseHelper.instance;

  ///*** ÖNCELİK ile ilgili Veritabanı İşlemleri ***

  ///İlk Öncelik bulan kod
  Future<Oncelikler> getIlkOncelik() async {
    final db = await _databaseHelper.database;

    final result = await db.query(
      tableOncelik,
      orderBy: '${OncelikAlanlar.id} ASC',
      limit: 1,
    );

    if (result.isNotEmpty) {
      return Oncelikler.fromJson(result.first);
    } else {
      throw Exception(AppLocalizations.of(context as BuildContext)
          .translate('general_notFound'));
    }
  }

  ///Öncelik Tek Satır  Okuma İşlemi
  Future<Oncelikler> getOncelikId(int id) async {
    final db = await _databaseHelper.database;

    final maps = await db.query(
      tableOncelik,
      columns: OncelikAlanlar.values,
      where: '${OncelikAlanlar.id} = ?',
      whereArgs: [id],
    );

    if (maps.isNotEmpty) {
      return Oncelikler.fromJson(maps.first);
    } else {
      throw Exception('ID $id not found');
    }
  }

  ///Öncelik Kayıtları Listeleme İşlemi
  Future<List<Oncelikler>> getAllOncelik() async {
    final db = await _databaseHelper.database;

    const orderBy = '${OncelikAlanlar.kayitZamani} ASC';

    final result = await db.query(tableOncelik, orderBy: orderBy);

    return result.map((json) => Oncelikler.fromJson(json)).toList();
  }

  ///Öncelik Kayıt Ekleme İşlemi
  Future<Oncelikler> createOncelik(Oncelikler oncelik) async {
    final db = await _databaseHelper.database;

    final id = await db.insert(tableOncelik, oncelik.toJson());
    return oncelik.copy(id: id);
  }

  ///Öncelik Kayıt Değiştirme İşlemi
  Future<int> updateOncelik(Oncelikler oncelik) async {
    final db = await _databaseHelper.database;

    return db.update(
      tableOncelik,
      oncelik.toJson(),
      where: '${OncelikAlanlar.id} = ?',
      whereArgs: [oncelik.id],
    );
  }

  ///Öncelik Kayıt Silme İşlemi
  Future<int> deleteOncelik(int id) async {
    final db = await _databaseHelper.database;

    return await db.delete(
      tableOncelik,
      where: '${OncelikAlanlar.id} = ?',
      whereArgs: [id],
    );
  }
}
